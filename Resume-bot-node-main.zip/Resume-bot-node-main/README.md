# AI Resume & Cover Letter Bot 🤖📄

A Telegram bot that generates professional resumes and cover letters using OpenAI.

## ✨ Features
- Multi-language support (English, Ukrainian, Russian, Norwegian)
- Resume or cover letter generation
- Clean PDF output
- Prompt-based control over AI behavior

## 🚀 Quick Start

1. Clone the repo
2. Install dependencies:
   ```bash
   npm install
   ```
3. Create a `.env` file:
   ```env
   BOT_TOKEN=your-telegram-bot-token
   OPENAI_API_KEY=your-openai-api-key
   ```
4. Run the bot:
   ```bash
   node index.js
   ```

## 🧠 Stack
- Node.js
- Telegram Bot API
- OpenAI API
- Puppeteer (PDF)
- Handlebars (HTML templates)

## 📄 License
MIT