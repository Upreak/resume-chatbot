const fs = require('fs');
const path = require('path');
const puppeteer = require('puppeteer');

async function generatePDF(data, outputPath) {
  const templatePath = path.join(__dirname, 'resume_template.html');
  let html = fs.readFileSync(templatePath, 'utf8');

// Clean out fields marked as "N/A"
const filteredData = {
  name: data.name === "N/A" ? "" : data.name,
  title: data.title === "N/A" ? "" : data.title,
  summary: data.summary === "N/A" ? "" : data.summary,
  experience: data.experience === "N/A" ? "" : data.experience,
  education: data.education === "N/A" ? "" : data.education,
  skills: Array.isArray(data.skills) ? data.skills.filter(s => s && s !== "N/A") : []
};

data = filteredData;


  html = html
    .replace('{{name}}', data.name)
    .replace('{{title}}', data.title)
    .replace('{{summary}}', data.summary)
    .replace('{{experience}}', data.experience)
    .replace('{{skills}}', data.skills.map(skill => `<li>${skill}</li>`).join('\n'))
    .replace('{{education}}', data.education);

  const browser = await puppeteer.launch({ headless: "new" });
  const page = await browser.newPage();
  await page.setContent(html, { waitUntil: 'networkidle0' });
  await page.pdf({ path: outputPath, format: 'A4' });
  await browser.close();
}

module.exports = generatePDF;