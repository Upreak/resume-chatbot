require('dotenv').config();
const TelegramBot = require('node-telegram-bot-api');
const OpenAI = require('openai');
const fs = require('fs');
const generatePDF = require('./generatePdf');

const bot = new TelegramBot(process.env.BOT_TOKEN, { polling: true });
const openai = new OpenAI({ apiKey: process.env.OPENAI_API_KEY });
const userStates = {};

const INTERFACE_LANGS = {
  "🇬🇧 English": "English",
  "🇺🇦 Українська": "Українська",
  "🇷🇺 Русский": "Русский",
  "🇳🇴 Norsk": "Norsk"
};

const DOC_LANGS = ["English", "Українська", "Русский", "Norsk"];

const LANG_TEXTS = {
  English: {
    start: "🌐 Please choose your language:",
    mainMenu: "What would you like to create?",
    resume: "📄 Create Resume",
    letter: "✉️ Cover Letter",
    chooseDocLang: "🗣 What language should the document be in?",
    generating: "⏳ Generating...",
    pdfReady: "📄 Here is your PDF!",
    failed: "❌ Failed to parse AI response.",
    questions: [
      "1️⃣ Enter your name and title:",
      "2️⃣ Describe your experience:",
      "3️⃣ List your skills:",
      "4️⃣ Describe your education:",
      "5️⃣ Anything else?"
    ],
    prompt: (type, lang, text) =>
      type === 'resume'
        ? `You are a professional resume writer. Create a professional CV in ${lang}. Use only the user's information, but rewrite it clearly and formally using the user input below. You may improve wording, fix grammar, and clarify meaning. It’s allowed to infer small details from context, but do not invent major job titles, companies, or skills. Return JSON:
{"name":"","title":"","summary":"","experience":"","skills":[""],"education":""}
User data:
${text}`
        : `You are an expert in writing cover letters. Write a professional letter in ${lang}, based on the user's input. You can improve clarity and flow, but do not invent experience or positions. Max 300 words. Return:
{"letter":"..."}
User data:
${text}`
  },
  Русский: {
    start: "🌐 Выберите язык:",
    mainMenu: "Что вы хотите создать?",
    resume: "📄 Создать резюме",
    letter: "✉️ Сопроводительное письмо",
    chooseDocLang: "🗣 На каком языке должен быть документ?",
    generating: "⏳ Генерация...",
    pdfReady: "📄 Вот ваш PDF!",
    failed: "❌ Не удалось обработать ответ AI.",
    questions: [
      "1️⃣ Введите имя и должность:",
      "2️⃣ Опишите опыт:",
      "3️⃣ Навыки:",
      "4️⃣ Образование:",
      "5️⃣ Что-то ещё?"
    ],
    prompt: (type, lang, text) =>
      type === 'resume'
        ? `Ты профессиональный составитель резюме. Составь CV на языке ${lang}, используя данные пользователя. Ты можешь улучшить формулировки, уточнить смысл и немного додумать из контекста. Но не выдумывай компании, должности или навыки. Ответ в JSON:
{"name":"","title":"","summary":"","experience":"","skills":[""],"education":""}
Информация:
${text}`
        : `Ты эксперт по написанию сопроводительных писем. Напиши письмо на языке ${lang} по данным пользователя. Можно улучшить стиль и выразительность, но не выдумывай опыт или профессии. До 300 слов. Ответ:
{"letter":"..."}
Инфо:
${text}`
  },
  Українська: {
    start: "🌐 Обери мову:",
    mainMenu: "Що ти хочеш створити?",
    resume: "📄 Створити резюме",
    letter: "✉️ Супровідний лист",
    chooseDocLang: "🗣 Якою мовою має бути документ?",
    generating: "⏳ Генерую...",
    pdfReady: "📄 Ось твій PDF!",
    failed: "❌ Не вдалося обробити відповідь AI.",
    questions: [
      "1️⃣ Введи ім'я та посаду:",
      "2️⃣ Опиши досвід:",
      "3️⃣ Вкажи навички:",
      "4️⃣ Опиши освіту:",
      "5️⃣ Щось ще?"
    ],
    prompt: (type, lang, text) =>
      type === 'resume'
        ? `Ти професійний автор резюме. Напиши професійне резюме українською мовою (${lang}). Удоскональ стиль без вигадування нових фактів, використовуючи наведені дані. Можна покращити стиль, граматику і трохи доповнити контекстом, але не вигадуй нові посади чи компанії. Вивід:
{"name":"","title":"","summary":"","experience":"","skills":[""],"education":""}
Дані:
${text}`
        : `Ти фахівець з написання супровідних листів. Напиши професійний лист українською мовою (${lang}), з урахуванням даних користувача. Можна покращити стиль, але не вигадуй досвід. До 300 слів. Формат:
{"letter":"..."}
Інфо:
${text}`
  },
  Norsk: {
    start: "🌐 Velg språk:",
    mainMenu: "Hva vil du lage?",
    resume: "📄 Lag CV",
    letter: "✉️ Søknadsbrev",
    chooseDocLang: "🗣 Hvilket språk skal dokumentet være på?",
    generating: "⏳ Genererer...",
    pdfReady: "📄 Her er din PDF!",
    failed: "❌ Klarte ikke å tolke AI-svar.",
    questions: [
      "1️⃣ Navn og stilling:",
      "2️⃣ Erfaring:",
      "3️⃣ Ferdigheter:",
      "4️⃣ Utdanning:",
      "5️⃣ Annet?"
    ],
    prompt: (type, lang, text) =>
      type === 'resume'
        ? `Du er en profesjonell CV-forfatter. Skriv et profesjonelt CV på ${lang}. Bruk kun brukerens info, men formuler det tydelig og profesjonelt, basert på informasjonen. Du kan forbedre teksten og trekke små konklusjoner fra konteksten, men ikke finn opp titler, firmaer eller erfaring. Returner:
{"name":"","title":"","summary":"","experience":"","skills":[""],"education":""}
Brukerdata:
${text}`
        : `Du er ekspert på søknadsbrev. Skriv et profesjonelt brev på ${lang}, opptil 300 ord. Forbedre uttrykket, men ikke finn på erfaring. Format:
{"letter":"..."}
Data:
${text}`
  }
};

bot.onText(/\/start/, (msg) => {
  const chatId = msg.chat.id;
  userStates[chatId] = { step: 0 };
  const keyboard = Object.keys(INTERFACE_LANGS).map(l => [l]);
  bot.sendMessage(chatId, "🌐 Please choose your language / Обери мову / Выберите язык / Velg språk:", {
    reply_markup: {
      keyboard,
      resize_keyboard: true,
      one_time_keyboard: true
    }
  });
});

bot.on("message", async (msg) => {
  const chatId = msg.chat.id;
  const text = msg.text;
  const state = userStates[chatId];
  if (!state) return;

  if (state.step === 0 && INTERFACE_LANGS[text]) {
    state.interfaceLang = INTERFACE_LANGS[text];
    state.step = 1;
    const t = LANG_TEXTS[state.interfaceLang];
    return bot.sendMessage(chatId, t.mainMenu, {
      reply_markup: {
        keyboard: [[t.resume], [t.letter]],
        resize_keyboard: true,
        one_time_keyboard: true
      }
    });
  }

  const lang = state.interfaceLang;
  const t = lang ? LANG_TEXTS[lang] : null;

  if (state.step === 1 && t && (text === t.resume || text === t.letter)) {
    state.type = text === t.resume ? "resume" : "letter";
    state.step = 2;
    return bot.sendMessage(chatId, t.chooseDocLang, {
      reply_markup: {
        keyboard: DOC_LANGS.map(l => [l]),
        resize_keyboard: true,
        one_time_keyboard: true
      }
    });
  }

  if (state.step === 2 && DOC_LANGS.includes(text)) {
    state.outputLang = text;
    state.step = 3;
    state.answers = [];
    return bot.sendMessage(chatId, t.questions[0]);
  }

  if (state.step >= 3 && state.step < 8) {
    state.answers.push(text);
    const qIndex = state.step - 2;
    state.step++;
    if (qIndex < t.questions.length - 1) {
      return bot.sendMessage(chatId, t.questions[qIndex]);
    }

    const cleaned = state.answers.map(a => (!a || a.trim().length < 2 ? "N/A" : a.trim()));
    const input = cleaned.join("\n");
    bot.sendMessage(chatId, t.generating);

    try {
      const prompt = t.prompt(state.type, state.outputLang, input);
      const completion = await openai.chat.completions.create({
        model: "gpt-3.5-turbo",
        messages: [{ role: "user", content: prompt }],
        temperature: 0.7
      });

      const raw = completion.choices[0].message.content;
      const json = JSON.parse(raw);

      if (json.title && /hr manager/i.test(json.title)) {
        json.title = "";
      }

      if (typeof json.skills === 'string') {
        json.skills = json.skills
          .replace(/skills|навыки|Навыки|Skills:/gi, '')
          .split(/[\n,;]+/)
          .map(s => s.trim())
          .filter(Boolean);
      }

      const filePath = `./doc_${chatId}.pdf`;

      if (state.type === 'resume') {
        await generatePDF(json, filePath);
      } else if (state.type === 'letter') {
        await generatePDF({
          name: json.name || '',
          title: json.title || '',
          summary: json.letter || json.coverLetter || '',
          experience: '',
          education: '',
          skills: []
        }, filePath);
      }

      await bot.sendDocument(chatId, filePath, { caption: t.pdfReady });
      fs.unlinkSync(filePath);
    } catch (e) {
      console.error(e);
      bot.sendMessage(chatId, t.failed);
    }

    delete userStates[chatId];
  }
});